function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6aM8Y0Kqlao":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

