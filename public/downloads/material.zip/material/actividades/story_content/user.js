function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6L7eedlXmYv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

